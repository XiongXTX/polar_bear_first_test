#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

class TemperatureSubscriber : public rclcpp::Node
{
public:
    TemperatureSubscriber() : Node("temperature_subscriber")
    {
        subscription_ = this->create_subscription<std_msgs::msg::Float64>(
            "temperature", 10, 
            std::bind(&TemperatureSubscriber::topic_callback, this, 
            std::placeholders::_1));
    }
private:
    void topic_callback(const std_msgs::msg::Float64::SharedPtr msg) const
    {
        double temperature = msg->data;
        double fahrenheit = (temperature * 9.0 / 5.0) + 32.0;
        RCLCPP_INFO(this->get_logger(), "received: %.2f°C, converted: %.2f°F", temperature, fahrenheit);
    }
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr subscription_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TemperatureSubscriber>());
    rclcpp::shutdown();
    return 0;
}