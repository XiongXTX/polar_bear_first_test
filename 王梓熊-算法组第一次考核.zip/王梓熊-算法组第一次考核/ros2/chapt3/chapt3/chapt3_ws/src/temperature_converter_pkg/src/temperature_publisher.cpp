#include <iostream>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

class TemperaturePublisher : public rclcpp::Node
{
public:
    TemperaturePublisher() : Node("temperature_publisher")
    {
        publisher_ = this->create_publisher<std_msgs::msg::Float64>("temperature", 10);
        RCLCPP_INFO(this->get_logger(), "请输入摄氏温度");
    }

    void publish_temperature(double temperature)
    {
        auto message = std_msgs::msg::Float64();
        message.data = temperature;
        publisher_->publish(message);
        RCLCPP_INFO(this->get_logger(), "摄氏温度: %.2f°C", temperature); 
    }
private:
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr publisher_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TemperaturePublisher>();

    double temperature;
    while (rclcpp::ok())
    {
        std::cout << "请输入摄氏温度: ";
        std::cin >> temperature;
        node->publish_temperature(temperature);
    }

    rclcpp::shutdown();
    return 0;
}