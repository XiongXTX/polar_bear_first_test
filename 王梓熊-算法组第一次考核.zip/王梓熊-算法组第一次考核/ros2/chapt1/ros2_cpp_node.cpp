#include "rclcpp/rclcpp.hpp"
int main(int argc,char** argv)
{
    rclcpp::init(argc, argv);//初始化
    auto node = rclcpp::Node::make_shared("my_node");//创建节点
    RCLCPP_INFO(node->get_logger(), "你好,C++节点!");//打印日志
    rclcpp::spin(node);//运行循环
    rclcpp::shutdown();
    return 0;
}