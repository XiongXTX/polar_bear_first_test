# CMake generated Testfile for 
# Source directory: /home/xiongtx/polar_bear_first_test/ros2
# Build directory: /home/xiongtx/polar_bear_first_test/ros2
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
