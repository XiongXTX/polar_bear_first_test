#include<stdio.h>

int main(){
    printf("名字:王梓熊\n");
    printf("入队寄语:祝好运，玩开心。\n");
    return 0;
}